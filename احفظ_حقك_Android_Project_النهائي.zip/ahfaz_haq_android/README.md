# احفظ حقك — Android 1.0.0

هذا المشروع يغلّف النسخة النهائية من تطبيق الويب داخل Android WebView.

## بناء APK
- افتح المشروع في Android Studio أو خدمة بناء Android سحابية.
- نفّذ Gradle task: `app:assembleDebug` لإخراج APK تجريبي.
- الناتج: `app/build/outputs/apk/debug/app-debug.apk`

النسخة المضمنة موجودة في `app/src/main/assets/index.html`.
